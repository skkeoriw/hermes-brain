---
name: llm-wiki
description: "Karpathy's LLM Wiki: build/query interlinked markdown KB."
version: 2.2.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [wiki, knowledge-base, research, notes, markdown, rag-alternative]
    category: research
    related_skills: [obsidian, arxiv]
---

# Karpathy's LLM Wiki

Build and maintain a persistent, compounding knowledge base as interlinked markdown files.
Based on [Andrej Karpathy's LLM Wiki pattern](https://gist.github.com/karpathy/442a6bf555914893e9891c11519de94f).

Unlike traditional RAG (which rediscovers knowledge from scratch per query), the wiki
compiles knowledge once and keeps it current. Cross-references are already there.
Contradictions have already been flagged. Synthesis reflects everything ingested.

**Division of labor:** The human curates sources and directs analysis. The agent
summarizes, cross-references, files, and maintains consistency.

## When This Skill Activates

Use this skill when the user:
- Asks to create, build, or start a wiki or knowledge base
- Asks to ingest, add, or process a source into their wiki
- Asks a question and an existing wiki is present at the configured path
- Asks to lint, audit, or health-check their wiki
- References their wiki, knowledge base, or "notes" in a research context

## Wiki Location

**Location:** Set via `WIKI_PATH` environment variable (e.g. in `~/.hermes/.env`).

If unset, defaults to `~/wiki`.

```bash
WIKI="${WIKI_PATH:-$HOME/wiki}"
```

The wiki is just a directory of markdown files — open it in Obsidian, VS Code, or
any editor. No database, no special tooling required.

## Architecture: Three Layers

```
wiki/
├── SCHEMA.md           # Conventions, structure rules, domain config
├── index.md            # Sectioned content catalog with one-line summaries
├── log.md              # Chronological action log (append-only, rotated yearly)
├── raw/                # Layer 1: Immutable source material
│   ├── articles/       # Web articles, clippings
│   ├── papers/         # PDFs, arxiv papers
│   ├── transcripts/    # Meeting notes, interviews
│   └── assets/         # Images, diagrams referenced by sources
├── entities/           # Layer 2: Entity pages (people, orgs, products, models)
├── concepts/           # Layer 2: Concept/topic pages
├── comparisons/        # Layer 2: Side-by-side analyses
└── queries/            # Layer 2: Filed query results worth keeping
```

**Layer 1 — Raw Sources:** Immutable. The agent reads but never modifies these.
**Layer 2 — The Wiki:** Agent-owned markdown files. Created, updated, and
cross-referenced by the agent.
**Layer 3 — The Schema:** `SCHEMA.md` defines structure, conventions, and tag taxonomy.

## Resuming an Existing Wiki (CRITICAL — do this every session)

When the user has an existing wiki, **always orient yourself before doing anything**—following the priority order: webhook prompt > repo TheSchema.md/SCHEMA.md > skill defaults.

① **Check for TheSchema.md first** (higher priority if present):
   - If `TheSchema.md` exists, read it to understand the domain, conventions, and tag taxonomy
   - If only `SCHEMA.md` exists, read it instead
② **Read `index.md`** — learn what pages exist and their summaries.
③ **Scan recent `log.md`** — read the last 20-30 entries to understand recent activity.

```bash
WIKI="${WIKI_PATH:-$HOME/wiki}"
# Orientation reads at session start (follow priority order)
if [ -f "$WIKI/TheSchema.md" ]; then
    read_file "$WIKI/TheSchema.md"
elif [ -f "$WIKI/SCHEMA.md" ]; then
    read_file "$WIKI/SCHEMA.md"
fi
read_file "$WIKI/index.md"
read_file "$WIKI/log.md" offset=<last 30 lines>
```

Only after orientation should you ingest, query, or lint. This prevents:
- Creating duplicate pages for entities that already exist
- Missing cross-references to existing content
- Contradicting the schema's conventions
- Repeating work already logged

**TheSchema.md layout variant:** When a repo uses `TheSchema.md` (vs `SCHEMA.md`), the expected wiki layout is:
```
wiki/
├── sources/          # Source summary pages
├── entities/         # Entity pages (people, orgs, products, models)
├── concepts/         # Concept/topic pages
├── comparisons/      # Side-by-side analyses
├── overview/         # Overview / synthesis pages
└── queries/          # Filed query results worth keeping
```
This layout also enforces a strict L1/L2/L3 layer model in frontmatter (`layer: L1|L2|L3`, with `confidence` and `reasoning` required for L2/L3 layers). See `references/theschema-layout.md` for full details.

For large wikis (100+ pages), also run a quick `search_files` for the topic
at hand before creating anything new.

## Initializing a New Wiki

When the user asks to create or start a wiki:

1. Determine the wiki path (from `$WIKI_PATH` env var, or ask the user; default `~/wiki`)
2. Create the directory structure above
3. Ask the user what domain the wiki covers — be specific
4. Write `SCHEMA.md` customized to the domain (see template below)
5. Write initial `index.md` with sectioned header
6. Write initial `log.md` with creation entry
7. Confirm the wiki is ready and suggest first sources to ingest

### SCHEMA.md Template

Adapt to the user's domain. The schema constrains agent behavior and ensures consistency:

```markdown
# Wiki Schema

## Domain
[What this wiki covers — e.g., "AI/ML research", "personal health", "startup intelligence"]

## Conventions
- File names: lowercase, hyphens, no spaces (e.g., `transformer-architecture.md`)
- Every wiki page starts with YAML frontmatter (see below)
- Use `[[wikilinks]]` to link between pages (minimum 2 outbound links per page)
- When updating a page, always bump the `updated` date
- Every new page must be added to `index.md` under the correct section
- Every action must be appended to `log.md`
- **Provenance markers:** On pages that synthesize 3+ sources, append `^[raw/articles/source-file.md]`
  at the end of paragraphs whose claims come from a specific source. This lets a reader trace each
  claim back without re-reading the whole raw file. Optional on single-source pages where the
  `sources:` frontmatter is enough.

## Frontmatter
  ```yaml
  ---
  title: Page Title
  created: YYYY-MM-DD
  updated: YYYY-MM-DD
  type: entity | concept | comparison | query | summary
  tags: [from taxonomy below]
  sources: [raw/articles/source-name.md]
  # Optional quality signals:
  confidence: high | medium | low        # how well-supported the claims are
  contested: true                        # set when the page has unresolved contradictions
  contradictions: [other-page-slug]      # pages this one conflicts with
  ---
  ```

`confidence` and `contested` are optional but recommended for opinion-heavy or fast-moving
topics. Lint surfaces `contested: true` and `confidence: low` pages for review so weak claims
don't silently harden into accepted wiki fact.

### raw/ Frontmatter

Raw sources ALSO get a small frontmatter block so re-ingests can detect drift:

```yaml
---
source_url: https://example.com/article   # original URL, if applicable
ingested: YYYY-MM-DD
sha256: <hex digest of the raw content below the frontmatter>
---
```

The `sha256:` lets a future re-ingest of the same URL skip processing when content is unchanged,
and flag drift when it has changed. Compute over the body only (everything after the closing
`---`), not the frontmatter itself.

## Tag Taxonomy
[Define 10-20 top-level tags for the domain. Add new tags here BEFORE using them.]

Example for AI/ML:
- Models: model, architecture, benchmark, training
- People/Orgs: person, company, lab, open-source
- Techniques: optimization, fine-tuning, inference, alignment, data
- Meta: comparison, timeline, controversy, prediction

Rule: every tag on a page must appear in this taxonomy. If a new tag is needed,
add it here first, then use it. This prevents tag sprawl.

## Page Thresholds
- **Create a page** when an entity/concept appears in 2+ sources OR is central to one source
- **Add to existing page** when a source mentions something already covered
- **DON'T create a page** for passing mentions, minor details, or things outside the domain
- **Split a page** when it exceeds ~200 lines — break into sub-topics with cross-links
- **Archive a page** when its content is fully superseded — move to `_archive/`, remove from index

## Entity Pages
One page per notable entity. Include:
- Overview / what it is
- Key facts and dates
- Relationships to other entities ([[wikilinks]])
- Source references

## Concept Pages
One page per concept or topic. Include:
- Definition / explanation
- Current state of knowledge
- Open questions or debates
- Related concepts ([[wikilinks]])

## Comparison Pages
Side-by-side analyses. Include:
- What is being compared and why
- Dimensions of comparison (table format preferred)
- Verdict or synthesis
- Sources

## Update Policy
When new information conflicts with existing content:
1. Check the dates — newer sources generally supersede older ones
2. If genuinely contradictory, note both positions with dates and sources
3. Mark the contradiction in frontmatter: `contradictions: [page-name]`
4. Flag for user review in the lint report
```

### index.md Template

The index is sectioned by type. Each entry is one line: wikilink + summary.

```markdown
# Wiki Index

> Content catalog. Every wiki page listed under its type with a one-line summary.
> Read this first to find relevant pages for any query.
> Last updated: YYYY-MM-DD | Total pages: N

## Entities
<!-- Alphabetical within section -->

## Concepts

## Comparisons

## Queries
```

**Scaling rule:** When any section exceeds 50 entries, split it into sub-sections
by first letter or sub-domain. When the index exceeds 200 entries total, create
a `_meta/topic-map.md` that groups pages by theme for faster navigation.

### log.md Template

```markdown
# Wiki Log

> Chronological record of all wiki actions. Append-only.
> Format: `## [YYYY-MM-DD] action | subject`
> Actions: ingest, update, query, lint, create, archive, delete
> When this file exceeds 500 entries, rotate: rename to log-YYYY.md, start fresh.

## [YYYY-MM-DD] create | Wiki initialized
- Domain: [domain]
- Structure created with SCHEMA.md, index.md, log.md
```

## Core Operations

### 1. Ingest

When the user provides a source (URL, file, paste), integrate it into the wiki:

① **Capture the raw source:**
   - URL → use `web_extract` to get markdown, save to `raw/articles/`
   - PDF → use `web_extract` (handles PDFs), save to `raw/papers/`
   - Pasted text → save to appropriate `raw/` subdirectory
   - Name the file descriptively: `raw/articles/karpathy-llm-wiki-2026.md`
   - **Add raw frontmatter** (`source_url`, `ingested`, `sha256` of the body).
     On re-ingest of the same URL: recompute the sha256, compare to the stored value —
     skip if identical, flag drift and update if different. This is cheap enough to
     do on every re-ingest and catches silent source changes.

② **Discuss takeaways** with the user — what's interesting, what matters for
   the domain. (Skip this in automated/cron contexts — proceed directly.)

③ **Check what already exists** — search index.md and use `search_files` to find
   existing pages for mentioned entities/concepts. This is the difference between
   a growing wiki and a pile of duplicates.

④ **Write or update wiki pages:**
   - **New entities/concepts:** Create pages only if they meet the Page Thresholds
     in SCHEMA.md (2+ source mentions, or central to one source)
   - **Existing pages:** Add new information, update facts, bump `updated` date.
     When new info contradicts existing content, follow the Update Policy.
   - **Cross-reference:** Every new or updated page must link to at least 2 other
     pages via `[[wikilinks]]`. Check that existing pages link back.
   - **Tags:** Only use tags from the taxonomy in SCHEMA.md
   - **Provenance:** On pages synthesizing 3+ sources, append `^[raw/articles/source.md]`
     markers to paragraphs whose claims trace to a specific source.
   - **Confidence:** For opinion-heavy, fast-moving, or single-source claims, set
     `confidence: medium` or `low` in frontmatter. Don't mark `high` unless the
     claim is well-supported across multiple sources.

⑤ **Update navigation:**
   - Add new pages to `index.md` under the correct section, alphabetically
   - Update the "Total pages" count and "Last updated" date in index header
   - Append to `log.md`: `## [YYYY-MM-DD] ingest | Source Title`
   - List every file created or updated in the log entry

⑥ **Report what changed** — list every file created or updated to the user.

A single source can trigger updates across 5-15 wiki pages. This is normal
and desired — it's the compounding effect.

### 2. Query

When the user asks a question about the wiki's domain:

① **Read `index.md`** to identify relevant pages.
② **For wikis with 100+ pages**, also `search_files` across all `.md` files
   for key terms — the index alone may miss relevant content.
③ **Read the relevant pages** using `read_file`.
④ **Synthesize an answer** from the compiled knowledge. Cite the wiki pages
   you drew from: "Based on [[page-a]] and [[page-b]]..."
⑤ **File valuable answers back** — if the answer is a substantial comparison,
   deep dive, or novel synthesis, create a page in `queries/` or `comparisons/`.
   Don't file trivial lookups — only answers that would be painful to re-derive.
⑥ **Update log.md** with the query and whether it was filed.

### 3. Lint

When the user asks to lint, health-check, or audit the wiki:

① **Orphan pages:** Find pages with no inbound `[[wikilinks]]` from other pages.
```python
# Use execute_code for this — programmatic scan across all wiki pages
import os, re
from collections import defaultdict
wiki = "<WIKI_PATH>"
# Scan all .md files in entities/, concepts/, comparisons/, queries/
# Extract all [[wikilinks]] — build inbound link map
# Pages with zero inbound links are orphans
```

② **Broken wikilinks:** Find `[[links]]` that point to pages that don't exist.

③ **Index completeness:** Every wiki page should appear in `index.md`. Compare
   the filesystem against index entries.

④ **Frontmatter validation:** Every wiki page must have all required fields
   (title, created, updated, type, tags, sources). Tags must be in the taxonomy.

⑤ **Stale content:** Pages whose `updated` date is >90 days older than the most
   recent source that mentions the same entities.

⑥ **Contradictions:** Pages on the same topic with conflicting claims. Look for
   pages that share tags/entities but state different facts. Surface all pages
   with `contested: true` or `contradictions:` frontmatter for user review.

⑦ **Quality signals:** List pages with `confidence: low` and any page that cites
   only a single source but has no confidence field set — these are candidates
   for either finding corroboration or demoting to `confidence: medium`.

⑧ **Source drift:** For each file in `raw/` with a `sha256:` frontmatter, recompute
   the hash and flag mismatches. Mismatches indicate the raw file was edited
   (shouldn't happen — raw/ is immutable) or ingested from a URL that has since
   changed. Not a hard error, but worth reporting.

⑨ **Page size:** Flag pages over 200 lines — candidates for splitting.

⑩ **Tag audit:** List all tags in use, flag any not in the SCHEMA.md taxonomy.

⑪ **Log rotation:** If log.md exceeds 500 entries, rotate it.

⑫ **Report findings** with specific file paths and suggested actions, grouped by
   severity (broken links > orphans > source drift > contested pages > stale content > style issues).

⑬ **Append to log.md:** `## [YYYY-MM-DD] lint | N issues found`

## Git-Backed Remote Wiki Automation

When the wiki lives in a remote Git repository rather than an already-local folder, treat the local clone as a cache of the canonical remote:

1. Clone once into a stable path and set `WIKI_PATH`/`OBSIDIAN_VAULT_PATH` to that clone.
2. Before every build, ingest, or query: verify a clean worktree, `git fetch`, `git checkout <branch>`, and `git pull --ff-only` from the canonical remote. Stop and report if there are uncommitted changes unless the user explicitly asked to preserve/commit them.
   - If the workflow requires preserving local edits automatically, use a protective stash sequence: `git stash push -u -m "webhook-auto-stash-<run_id>"` → sync (`fetch/checkout/pull --ff-only`) → `git stash pop` before processing.
   - If `stash pop` reports conflicts, log conflict details and abort the run (do not force-commit partial conflict state).
   - If `git pull --ff-only` fails with local/remote divergence (e.g. `ahead X, behind Y`), classify as `aborted:sync_ff_only_failed` and stop wiki processing. For operator remediation in unattended environments, use: create a safety branch from local `main` (`backup/local-main-before-reset-<utc>`), then `git reset --hard origin/main`, then re-trigger webhook/job.
3. For full builds, scan all markdown and repair/init `SCHEMA.md`, `index.md`, `log.md`, entity/concept/comparison/query pages, frontmatter, backlinks, and graph structure.
4. For incremental builds, diff against the pulled baseline or recent commits to identify changed markdown, then update only affected pages plus `index.md` and `log.md`.
   - **Do not infer "no changes" from `git pull` output** (`Already up to date` is sync status, not content-diff status).
   - Prefer payload-provided `before..sha` when both are valid. If the computed command yields an empty set because the range is malformed/degenerate (e.g., leading `..sha` with missing base), immediately fallback to `HEAD~1..HEAD` and log both commands + why fallback was used.
   - After diffing, hard-filter to `raw/**/*.md`; if none remain, record `skipped:no_raw_changes` and stop without wiki writes/commit/push.
   - **Pre-existing-output guard:** Before creating new wiki pages for a raw change, check if the expected output pages already exist in HEAD. If they do (e.g., a previous run committed them locally but failed to push, leaving origin behind), log the finding, skip duplicate page creation, and only fix any formatting/consistency issues found. Stale `before..sha` diffs from unpushed upstream commits are a false positive — the work is already done. Blindly re-creating pages risks duplicate entries, broken formatting from concurrent writes, and index inconsistencies.
   - If the webhook contract requires a fixed run-log path (e.g., `logs/webhook-runs/gh-<run_id>-<attempt>.md`) on **every** run, create/append that file even when skipped; record skip reason explicitly.
5. For queries, orient first (schema/index/log), answer from wiki pages, and if the user wants query capture, write a `queries/` page and update navigation/log.
6. After write operations: `git status`, then commit only when changes exist. Default to `git add -A && git commit -m "chore: update llm wiki graph"`, **but if the repo already contains unrelated untracked files from other runs, stage only the files touched by this run** to avoid accidentally bundling stale artifacts. Push to the user-approved target branch; direct `main` pushes are acceptable only when explicitly requested.
   - Verification guard (important): immediately run `git show --name-only --oneline -n 1 <build_commit>` (or `git show --name-only --oneline -n 1 HEAD` right after commit) and confirm the expected wiki/index/log/run-log files are actually in that commit. If expected files are missing, do not continue to summary/Telegram—fix staging and recommit first.
   - Shell pitfall: avoid chaining `&& ...` directly after a heredoc terminator in one wrapped command block (`python3 - <<'PY' ... PY && ...`) on constrained runners; some wrappers throw parse errors. Prefer two separate terminal calls (script first, then git add/commit/push).
- GitHub Actions YAML pitfall: in `run: |` heredocs, the closing marker (e.g., `JSON`) must be indented consistently with the shell block. Mis-indentation can produce `Invalid workflow file ... yaml syntax` errors that look unrelated to shell logic.
- Raw-change gate pitfall: do not compute diffs inside an ad-hoc `git init tmprepo` without checkout. Prefer `actions/checkout@v4` with adequate history and then `git diff "$BEFORE" "$AFTER" -- 'raw/**/*.md'` (or equivalent pathspec count). Verify with run logs that `changed_count` is non-zero for raw edits and that webhook calls are skipped only when `changed_count=0`.
7. For Hermes webhook/API automation, put the operation selector in payload fields such as `action=full_build|incremental_build|query`, `question`, and `save`, and make the prompt repeat the sync-before/worktree-clean/push-after rules.
   - If a manual trigger reaches the agent without explicit payload/action fields, default to `incremental_build`, explicitly record this assumption in `logs/webhook-runs/<run_id>.md`, and apply the normal incremental notification gates.
8. When the payload requires a detailed run log under `logs/webhook-runs/<run_id>.md`, include the run log in the same run's commit, and record start time, payload, sync command/result, key files read, created/updated/deleted lists, git status, errors, and end time.
   - If webhook payload provides `run_id`, use that exact filename (do not regenerate a new one). If `run_id` is missing, fallback to `delivery_id`, then UTC timestamp.
   - If the run-log file already exists, append a new run section for the current execution instead of overwriting previous content. In final user/Telegram summaries, explicitly include the run-log file path.
   - Stash-order guard: run the protective stash/sync/pop sequence first, then create or append the current run-log file. Creating the run-log before `git stash pop` can cause `already exists, no checkout` restore errors for untracked files.
   - If `git stash pop` fails, classify the failure: abort on merge/content conflicts or non-log restore conflicts; but if the only restore collision is the current run-log path under `logs/webhook-runs/<run_id>.md`, record it as a non-blocking warning and continue.
9. If the run log itself must contain commit hash and push result, plan for a two-commit sequence: first commit/push the wiki changes and initial log, then append the build commit hash and push result to the log and make a second one-file "finalize webhook run log" commit. A commit cannot truthfully contain its own final hash inside its content. In final/Telegram summaries, report both the build commit and the log-finalization commit when this happens. See `references/webhook-run-logging.md`.
10. In busy repos (multiple webhook runs close together), do **not** assume `git rev-parse HEAD` is the build commit to report. Verify the build commit by checking which commit actually contains this run’s changed files (especially `logs/webhook-runs/<run_id>.md` and run-touched wiki files) using `git show --name-only <commit>`; then report that explicit build hash alongside the finalize-log hash.

Pitfalls:
- Do not assume webhook callers get the final answer synchronously; Hermes webhooks are best for async trigger + delivery. Use the API Server (`/v1/chat/completions`) when the caller must synchronously receive the result.
- Direct push to `main` requires working Git credentials on the server; `gh` may be absent, so verify plain `git push` auth before promising automation is complete.
- **Push discipline (critical):** After ANY local write operation (raw files, wiki pages, index, log), you MUST git add + commit + push in the same turn without waiting to be asked. Users find it extremely frustrating to discover the agent stopped at commit and left changes local. The sequence is always: write → git add -A → git commit → git push, atomically.
- **PAT-in-URL auth:** When a GitHub PAT is provided, embed it in the remote URL: `git remote set-url origin https://<PAT>@github.com/<owner>/<repo>.git` then push normally. No other auth setup needed.
- Credential-identity guard: before unattended webhook runs that must push, verify the effective git identity/token owner matches the target repo permission (e.g., `git remote -v`, `git config --get credential.username` if set, and a dry auth probe like `git ls-remote origin`). If push later fails with 403 (wrong account/token), classify as `aborted:push_auth_failed`, record the exact remote error in run-log, and suppress Telegram notifications that require successful push.
- If `git push` fails with auth/permission errors (e.g., `HTTP 403`, `denied to <user>`), classify run as `error:push_failed`, record the exact remote error string in `logs/webhook-runs/<run_id>.md`, and stop notification side effects (especially Telegram) because "build commit + push success" gate is not met.
- Restart the Hermes gateway after enabling webhook/API-server platform config; creating subscriptions alone does not make ports listen.
- For unattended webhook runs, avoid `git reset --hard` remediation inside the agent loop. It is usually approval-gated (`Dangerous command requires approval`) and can stall or discard useful local artifacts. Preferred behavior: `fetch/checkout/pull --ff-only` + stash/pop policy; if divergence cannot be fast-forwarded, log and abort with explicit manual-action guidance.
- If a GitHub Action webhook call returns `HTTP 502`, verify gateway uptime window before debugging payload/auth. A gateway restart/drain window can produce transient 502 even when workflow and secrets are correct; correlate Action timestamp with `~/.hermes/logs/gateway.log` disconnect/start events.
- Some existing Obsidian wiki repos are non-canonical: schema may be `TheSchema.md`, active files may live under `wiki/index.md`/`wiki/log.md`, and root `SCHEMA.md`/`index.md`/`log.md` may be missing or empty. In that case, read the available schema first, then repair/init the canonical metadata without touching `raw/`; keep compatibility by updating both root and `wiki/` index/log when the repo already uses that layout.
- **TheSchema.md layout variant:** When a repo uses `TheSchema.md` (vs `SCHEMA.md`), the expected wiki layout is `raw/` + `wiki/sources/` + `wiki/entities/` + `wiki/concepts/` + `wiki/comparisons/` + `wiki/overview/` + `wiki/queries/` (no top-level `entities/` or `concepts/`). This layout also enforces a strict L1/L2/L3 layer model in frontmatter (`layer: L1|L2|L3`, `confidence`, `reasoning` required for L2/L3). See `references/theschema-layout.md` for full details.
- **Raw file content for translated sources:** When the user asks for foreign-language sources to be "translated into Chinese and written to raw", the raw file should contain: YAML frontmatter (title_zh, title_en, source_url, arxiv_id, ingested, tags) + full Chinese translation of the abstract as body text. Do NOT keep the English abstract as a separate section unless the user explicitly requests bilingual format.
- Conflict-precedence guard (important for webhook + skill coexistence): when a webhook subscription prompt defines explicit repo rules, apply precedence `webhook prompt > repository canonical schema (often TheSchema.md) > bridge SCHEMA.md > generic llm-wiki defaults`. Do not let generic skill defaults overwrite repo-specific contracts.
- Path-unification guard: if webhook automation uses a fixed local clone path but manual queries rely on `${WIKI_PATH:-~/wiki}`, verify/align `WIKI_PATH` (and optionally `OBSIDIAN_VAULT_PATH`) to the same repo path to prevent dual-track reads/writes.
- On some headless hosts, `python` is not installed but `python3` is. For any inline helper scripts used during webhook runs (log appenders, file list processors, quick markdown transforms), prefer `python3 - <<'PY'` to avoid avoidable runtime failure.
- For webhook-style requests that include `save=false`, do **not** create a `queries/` page, but still append a query log entry and include `Filed query page: no` in the final/Telegram summary.
- If the user explicitly requires Telegram delivery, send the same operational summary to Telegram after commit/push, including action, sync status, files changed, commit hash, answer/build summary, and errors.
- If the webhook contract explicitly forbids route-level `deliver=telegram` and requires **Telegram Bot API direct-send**, use `curl` to call `https://api.telegram.org/bot<TOKEN>/sendMessage` with the provided `chat_id`, and record API success/failure in the run log. Do not substitute Hermes webhook delivery for this requirement.
- Telegram template guard (important): before sending, build the payload text from an explicit key checklist and verify all required keys are present exactly as specified by contract (e.g., `raw_changed_files`, not misspellings like `fraw_changed_files`). If a malformed message was already sent, immediately resend a corrected template message, record both message IDs in run-log, and mark the first as superseded.
- For webhook contracts that ask for **quantitative Telegram summaries**, include explicit metrics rather than generic “graph updated” text:
  - new entity count + entity names,
  - changed raw source count + source file list,
  - relation changes grouped by type (e.g., `entity->concept`, `entity->source`) plus at least 3 sample edges,
  - affected concept-page list.
  If any metric cannot be computed, report `unknown` and state the reason.
- In webhook contracts that gate notifications, honor the gate strictly: e.g., **incremental_build only**, `raw/**/*.md` changed, and actual graph/wiki updates occurred. If the run is `skipped:no_raw_changes`, do not send Telegram.

## Working with the Wiki

### Searching

```bash
# Find pages by content
search_files "transformer" path="$WIKI" file_glob="*.md"

# Find pages by filename
search_files "*.md" target="files" path="$WIKI"

# Find pages by tag
search_files "tags:.*alignment" path="$WIKI" file_glob="*.md"

# Recent activity
read_file "$WIKI/log.md" offset=<last 20 lines>
```

### Bulk Ingest

When ingesting multiple sources at once, batch the updates:
1. Read all sources first
2. Identify all entities and concepts across all sources
3. Check existing pages for all of them (one search pass, not N)
4. Create/update pages in one pass (avoids redundant updates)
5. Update index.md once at the end
6. Write a single log entry covering the batch

### Archiving

When content is fully superseded or the domain scope changes:
1. Create `_archive/` directory if it doesn't exist
2. Move the page to `_archive/` with its original path (e.g., `_archive/entities/old-page.md`)
3. Remove from `index.md`
4. Update any pages that linked to it — replace wikilink with plain text + "(archived)"
5. Log the archive action

### Obsidian Integration

The wiki directory works as an Obsidian vault out of the box:
- `[[wikilinks]]` render as clickable links
- Graph View visualizes the knowledge network
- YAML frontmatter powers Dataview queries
- The `raw/assets/` folder holds images referenced via `![[image.png]]`

For best results:
- Set Obsidian's attachment folder to `raw/assets/`
- Enable "Wikilinks" in Obsidian settings (usually on by default)
- Install Dataview plugin for queries like `TABLE tags FROM "entities" WHERE contains(tags, "company")`

If using the Obsidian skill alongside this one, set `OBSIDIAN_VAULT_PATH` to the
same directory as the wiki path.

### Obsidian Headless (servers and headless machines)

On machines without a display, use `obsidian-headless` instead of the desktop app.
It syncs vaults via Obsidian Sync without a GUI — perfect for agents running on
servers that write to the wiki while Obsidian desktop reads it on another device.

**Setup:**
```bash
# Requires Node.js 22+
npm install -g obsidian-headless

# Login (requires Obsidian account with Sync subscription)
ob login --email <email> --password '<password>'

# Create a remote vault for the wiki
ob sync-create-remote --name "LLM Wiki"

# Connect the wiki directory to the vault
cd ~/wiki
ob sync-setup --vault "<vault-id>"

# Initial sync
ob sync

# Continuous sync (foreground — use systemd for background)
ob sync --continuous
```

**Continuous background sync via systemd:**
```ini
# ~/.config/systemd/user/obsidian-wiki-sync.service
[Unit]
Description=Obsidian LLM Wiki Sync
After=network-online.target
Wants=network-online.target

[Service]
ExecStart=/path/to/ob sync --continuous
WorkingDirectory=/home/user/wiki
Restart=on-failure
RestartSec=10

[Install]
WantedBy=default.target
```

```bash
systemctl --user daemon-reload
systemctl --user enable --now obsidian-wiki-sync
# Enable linger so sync survives logout:
sudo loginctl enable-linger $USER
```

This lets the agent write to `~/wiki` on a server while you browse the same
vault in Obsidian on your laptop/phone — changes appear within seconds.

## Pitfalls

- **Never modify files in `raw/`** — sources are immutable. Corrections go in wiki pages.
- **Always orient first** — read SCHEMA + index + recent log before any operation in a new session.
  Skipping this causes duplicates and missed cross-references.
- **Never delete or modify SCHEMA.md** — it defines the wiki's structure, conventions, and layer model.
  Deleting it breaks orientation and causes the agent to lose domain context.
- **Always update index.md and log.md** — skipping this makes the wiki degrade. These are the
  navigational backbone.
- **Don't create pages for passing mentions** — follow the Page Thresholds in SCHEMA.md. A name
  appearing once in a footnote doesn't warrant an entity page.
- **Don't create pages without cross-references** — isolated pages are invisible. Every page must
  link to at least 2 other pages.
- **Frontmatter is required** — it enables search, filtering, and staleness detection.
- **Tags must come from the taxonomy** — freeform tags decay into noise. Add new tags to SCHEMA.md
  first, then use them.
- **Keep pages scannable** — a wiki page should be readable in 30 seconds. Split pages over
  200 lines. Move detailed analysis to dedicated deep-dive pages.
- **Ask before mass-updating** — if an ingest would touch 10+ existing pages, confirm
  the scope with the user first.
- **Rotate the log** — when log.md exceeds 500 entries, rename it `log-YYYY.md` and start fresh.
  The agent should check log size during lint.
- **Handle contradictions explicitly** — don't silently overwrite. Note both claims with dates,
  mark in frontmatter, flag for user review.
- **Pre-existing-output false positive (incremental webhook runs):** When a previous run committed
  wiki pages locally but failed to push (e.g., 403), and a new run triggers with the same `before..sha`
  diff range on the same local HEAD, the diff still shows the raw file as "new". Always check if the
  target wiki pages already exist in HEAD before creating them. Stale `origin/main` + new local commits
  = diff false positive. Log the finding as `skipped:work_already_done` rather than re-creating pages.

## References

- `references/incremental-build-gate-checklist.md` — strict webhook incremental gate runbook (`before..sha` diff precedence, skip semantics, Telegram gating, fixed run-log behavior).
- `references/webhook-run-logging.md` — two-commit run-log finalization pattern and reporting expectations.
- `references/webhook-automation-pattern.md` — canonical webhook automation pattern for llm-wiki (precedence order, stash/sync workflow, run-log requirements, git discipline).
- `references/notebooklm-integration.md` — pattern for integrating NotebookLM-generated outputs (reports, mindmaps) into llm-wiki knowledge base.
## YouTube Wiki Processing Pattern

See `references/youtube-wiki-processing.md` for the pattern used to process YouTube video links
into a structured wiki using NotebookLM for analysis and llm-wiki for knowledge graph construction.

### YouTube-Specific Processing Guidelines (MANDATORY)

When processing YouTube video links in a webhook context, the following rules are **strictly enforced**:

1. **Two-Stage Processing** (from TheSchema.md):
   - Stage B: NotebookLM processing ONLY (triggered by changes in `raw/youtube-links/`)
   - Stage C: llm-wiki incremental build ONLY (triggered by changes in `raw/notebooklm-analysis/` or `raw/notebooklm-mindmaps/`)
   - **CRITICAL: Do NOT send Telegram notifications after Stage B** — Telegram is sent ONLY after Stage C completion with actual wiki updates

2. **Source-Scoped Generation** (NON-NEGOTIABLE):
   - When generating reports/mindmaps from NotebookLM, use ONLY the newly added source(s)
   - NEVER use whole-notebook context for generation
   - This ensures insights are traceable to specific videos and prevents contamination

3. **Language Enforcement** (MUST BE zh_Hans):
   - All generated content MUST be in Chinese (zh_Hans)
   - Set language explicitly: `notebooklm language set zh_Hans`
   - ALWAYS use `--language zh_Hans` flag on generate commands

4. **File Organization** (STRICT FORMAT):
   - YouTube links: `raw/youtube-links/<video-id>.md` (containing just the URL)
   - NotebookLM outputs:
     - Reports: `raw/notebooklm-analysis/<video-id>_<source-id>_<timestamp>_report.md`
     - Mindmaps: `raw/notebooklm-mindmaps/<video-id>_<source-id>_<timestamp>_mindmap.json`
   - Wiki outputs follow standard llm-wiki structure in `wiki/` directory

5. **Telegram Notification Requirements** (Stage C ONLY):
   - Sent ONLY after Stage C when raw changes occurred AND wiki updates succeeded
   - **MUST include quantitative metrics**:
     - New entity count + names (≤5 listed)
     - Changed/new raw source count + file list
     - Relation changes grouped by type (with ≥3 sample edges)
     - Affected concept-page list (≤5 listed)
   - **MUST include**: build commit hash and run-log file path
   - **MUST USE FORMAT**: `[YOUTUBE-WIKI-RUN]` prefix with key=value pairs

6. **Quality Controls** (HARD REQUIREMENTS):
   - Every wiki page MUST have minimum 2 outgoing `[[wikilinks]]`
   - Source pages: ≥300 Chinese characters
   - Entity/concept pages: ≥200 Chinese characters
   - Frontmatter MUST be complete: type/tags/summary/sources/updated/layer
   - For L2/L3 layers: confidence AND reasoning fields are REQUIRED

### YouTube-Specific Processing Guidelines

When processing YouTube video links in a webhook context:

1. **Two-Stage Processing** (as defined in TheSchema.md):
   - Stage B: NotebookLM processing (triggered by changes in `raw/youtube-links/`)
   - Stage C: llm-wiki incremental build (triggered by changes in `raw/notebooklm-analysis/` or `raw/notebooklm-mindmaps/`)
   - **Do not send Telegram notifications after Stage B** - only after Stage C with actual wiki updates

2. **Source-Scoped Generation**:
   - When generating reports/mindmaps from NotebookLM, use ONLY the newly added source(s)
   - Do not use whole-notebook context for generation
   - This ensures insights are traceable to specific videos

3. **Language Enforcement**:
   - All generated content must be in Chinese (zh_Hans)
   - Set language explicitly: `notebooklm language set zh_Hans`
   - Use `--language zh_Hans` flag on generate commands

4. **File Organization**:
   - YouTube links: `raw/youtube-links/<video-id>.md` (containing just the URL)
   - NotebookLM outputs: 
     - Reports: `raw/notebooklm-analysis/<video-id>_<source-id>_<timestamp>_report.md`
     - Mindmaps: `raw/notebooklm-mindmaps/<video-id>_<source-id>_<timestamp>_mindmap.json`
   - Wiki outputs follow standard llm-wiki structure

5. **Telegram Notification Requirements** (only after Stage C):
   - Must include quantitative metrics:
     - New entity count + names (≤5 listed)
     - Changed/new raw source count + file list
     - Relation changes grouped by type (with ≥3 sample edges)
     - Affected concept-page list (≤5 listed)
   - Must include build commit hash and run-log file path
   - Format: `[YOUTUBE-WIKI-RUN]` prefix with key=value pairs

6. **Quality Controls**:
   - Every wiki page must have minimum 2 outgoing `[[wikilinks]]`
   - Source pages: ≥300字, entity/concept pages: ≥200字
   - Frontmatter must be complete (type/tags/summary/sources/updated/layer, with confidence+reasoning for L2/L3)
