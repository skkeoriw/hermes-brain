# Hermes Brain Sync / Portable Hermes Home

Use when a user wants to reuse the same Hermes Agent "brain" across many machines: memories, skills, sessions, webhooks, config, and optionally plaintext test credentials.

## Recommended project shape

Create a private GitHub repository such as `hermes-brain` with this layout:

```text
hermes-brain/
  README.md
  SECURITY.md
  .gitignore
  brain/hermes-home/        # maps to ~/.hermes/
  scripts/
    bootstrap_new_machine.sh
    sync_from_local_to_repo.sh
    sync_from_repo_to_local.sh
    install_hermes.sh
    doctor.sh
  skills/hermes-brain-sync/SKILL.md
  docs/
    full-data-map.md
    new-machine-runbook.md
    conflict-policy.md
    plaintext-secret-sync.md
```

`brain/hermes-home/` is the canonical copy of `${HERMES_HOME:-$HOME/.hermes}`.

## What to sync

For a full test clone, sync most persistent Hermes state:

- `config.yaml`
- `.env` when the user explicitly accepts plaintext secret sync
- `auth.json` when the user explicitly accepts plaintext secret sync
- `memories/`
- `skills/`
- `sessions/`
- `state.db`
- `webhook_subscriptions.json`
- `channel_directory.json`
- `gateway_state.json`
- `pairing/`
- `profiles/`
- custom prompts/SOP files under `~/.hermes/`

Exclude runtime/rebuildable data:

- `hermes-agent/` source tree and virtualenv
- `logs/`
- `cache/`, `audio_cache/`
- `__pycache__/`, `*.pyc`
- `*.lock`
- `*.pid`
- `*.log`
- `*-wal`, `*-shm`
- `.update_check`

## Plaintext secret mode

If the user says this is only for testing and explicitly does not want encryption, support private-repo plaintext sync but write strong warnings into `README.md` and `SECURITY.md`:

- private repository only
- no untrusted collaborators
- if exposed, rotate/revoke every token
- Git history preserves deleted plaintext secrets

Do not keep arguing for encryption after the user explicitly chooses plaintext test mode; state the risk and implement the requested mode.

## Script implementation notes

Do not require `rsync` unless it is actually installed. A portable fallback is a small Python copier using `shutil.copytree/copy2`, with an exclude predicate for runtime files. This avoids failing on minimal machines.

New-machine bootstrap should:

1. Check `git`, `curl`, `python3`.
2. Install Hermes if `hermes` is missing.
3. Back up existing `${HERMES_HOME:-$HOME/.hermes}` to `~/.hermes-brain-backups/`.
4. Restore `brain/hermes-home/` to `${HERMES_HOME:-$HOME/.hermes}`.
5. `chmod 700 ~/.hermes` and `chmod 600` on `.env`, `auth.json`, `config.yaml`, webhook config if present.
6. Run `hermes doctor`.
7. Only start gateway if the machine is intended to receive messages/webhooks.

## GitHub creation/push pitfalls

- If the runtime blocks direct API calls containing a user-provided GitHub token, do not retry the blocked command. Finish the local repo and give the user exact manual steps: create a private empty repo, then `git remote add origin ... && git push -u origin main`.
- Prefer using existing Git credential store or `gh` if available; check before asking for another token.
- Do not print or repeat tokens in final responses.
