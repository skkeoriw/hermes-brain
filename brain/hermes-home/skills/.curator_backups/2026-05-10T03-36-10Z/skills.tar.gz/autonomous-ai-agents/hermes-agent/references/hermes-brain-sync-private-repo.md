# Hermes Brain Sync via Private Git Repository

Session-derived pattern for users who want to clone/synchronize a Hermes "brain" across many machines.

## User Intent

The user wants a GitHub project, likely named `hermes-brain` with README title `Hermes 大脑`, that allows a new machine to:

1. Install Hermes for that machine.
2. Clone the brain repository.
3. Restore all accumulated Hermes capabilities and persistent data.
4. Continue syncing local changes back to the repository.

The target workflow should be usable by another agent/Copilot after cloning the repo: documentation, scripts, and an in-repo skill should explain the process end to end.

## Recommended Repository Shape

```text
hermes-brain/
  README.md
  SECURITY.md
  .gitignore
  brain/
    hermes-home/
      config.yaml
      .env
      auth.json
      memories/
      skills/
      sessions/
      state.db
      webhook_subscriptions.json
      channel_directory.json
      gateway_state.json
      pairing/
      profiles/
      ...
  scripts/
    bootstrap_new_machine.sh
    sync_from_local_to_repo.sh
    sync_from_repo_to_local.sh
    backup_local_hermes.sh
    install_hermes.sh
    doctor.sh
  skills/
    hermes-brain-sync/
      SKILL.md
  docs/
    full-data-map.md
    new-machine-runbook.md
    conflict-policy.md
    plaintext-secret-sync.md
```

## Full Plaintext Sync Mode

Although encrypted secret sync is safer, the user explicitly requested plaintext secret sync for testing: private repo, no encryption, secrets considered unimportant. Respect this when implementing the requested project, but still include a visible warning in README/SECURITY.

Data to support syncing:

- `~/.hermes/memories/` (`MEMORY.md`, `USER.md`)
- `~/.hermes/skills/`
- `~/.hermes/sessions/`
- `~/.hermes/state.db` when doing full clone/migration
- `~/.hermes/webhook_subscriptions.json`
- `~/.hermes/config.yaml`
- `~/.hermes/.env`
- `~/.hermes/auth.json`
- `~/.hermes/pairing/`
- `~/.hermes/channel_directory.json`
- `~/.hermes/gateway_state.json`
- `~/.hermes/profiles/`
- custom prompts/SOP files such as `wiki_ops_webhook_prompt.txt`
- other durable Hermes files found under `~/.hermes/`

Exclude runtime/rebuildable/transient files:

- `~/.hermes/hermes-agent/` entirely, not just `venv/` — source checkout and its git objects are reinstallable and can balloon the brain repo.
- `~/.hermes/logs/`
- caches such as `cache/`, `audio_cache/`, model caches where appropriate
- `~/.hermes/checkpoints/` — Hermes filesystem checkpoints are often nested Git repos with thousands of objects; if accidentally tracked, the next sync should delete them from the repo snapshot and add `brain/hermes-home/checkpoints/` to `.gitignore`.
- `state.db-wal`, `state.db-shm`
- `*.lock`
- `*.pid`, `*.log`, `*.pyc`, temp files

## Script Semantics

### `sync_from_local_to_repo.sh`

Copy allowed durable data from `$HERMES_HOME` or `~/.hermes` to `brain/hermes-home/`, excluding runtime files. Then show `git diff` and optionally commit/push.

### `sync_from_repo_to_local.sh`

Restore `brain/hermes-home/` into local Hermes home. Always back up existing `~/.hermes` first. Fix permissions for secret-bearing files (`chmod 600 .env auth.json` where present).

### `bootstrap_new_machine.sh`

1. Check `git`, `curl`, `python3`.
2. Install Hermes if `hermes` is not available.
3. Back up existing Hermes home.
4. Restore repo brain to local Hermes home.
5. Run `hermes doctor`.
6. Optionally install/start gateway.

## In-Repo Skill

The repository should include `skills/hermes-brain-sync/SKILL.md`, a class-level runbook telling future agents how to:

- identify this repo as the portable Hermes brain,
- bootstrap a fresh machine,
- pull repo data into local Hermes,
- push local Hermes changes back,
- handle conflicts,
- distinguish durable data from runtime junk,
- understand the deliberate plaintext-secret testing mode.

## Warnings to Include

Even if plaintext is requested, document clearly:

```text
WARNING: This private repository may contain plaintext credentials, API keys, OAuth tokens, webhook secrets, and gateway pairing data. Use only for testing/trusted machines. Do not make public. Rotate credentials before production use.
```

## Existing User Repository Instance

For this user/machine, the repo already exists:

- Local path: `/home/zhouhuijuan1987/hermes-brain`
- Remote: `https://github.com/ChangfengHU/hermes-brain.git`
- Branch: `main`
- Core helper: `scripts/hermes_brain_sync.py`
- Wrappers: `scripts/sync_from_local_to_repo.sh`, `scripts/sync_from_repo_to_local.sh`, `scripts/bootstrap_new_machine.sh`, `scripts/doctor.sh`
- In-repo runbook skill: `skills/hermes-brain-sync/SKILL.md`

When asked to continue this project, first inspect that existing repo rather than creating a new one. The remote was created as a private repo using the machine's GitHub credential store for user `ChangfengHU`.

## Verification Pattern

After implementing or changing the brain sync workflow, verify without overwriting the real Hermes home:

```bash
VERIFY_DIR=/tmp/hermes-brain-verify-$$
mkdir -p "$VERIFY_DIR"
cd "$VERIFY_DIR"
git clone --depth 1 https://github.com/ChangfengHU/hermes-brain.git clone
cd clone
bash scripts/doctor.sh || true
HERMES_HOME="$VERIFY_DIR/restored-hermes" python3 scripts/hermes_brain_sync.py repo-to-local --no-backup
for p in memories skills sessions config.yaml .env auth.json; do
  test -e "$VERIFY_DIR/restored-hermes/$p" && echo "RESTORED $p" || echo "MISSING $p"
done
```

This confirms clone + restore semantics while leaving `~/.hermes` untouched.

## Conflict Notes

`state.db` and `sessions/` can conflict if multiple machines write concurrently. For strict full clone, support syncing them. For long-running multi-machine use, prefer the user's chosen single-writer topology:

```text
push machine: ~/.hermes -> repo brain/hermes-home -> GitHub
pull machines: GitHub -> repo brain/hermes-home -> ~/.hermes
```

Do not store per-machine role inside `brain/hermes-home/`; that content is restored into every machine. Store local role outside the synced brain, e.g. `~/.config/hermes-brain/sync-role` and `~/.config/hermes-brain/machine-id`, and store only a global push-owner declaration in the repo, e.g. `brain/sync-owner.json`. New machines should default to `pull`. A machine becomes the sole writer only when explicitly promoted with the repo helper such as `scripts/set_sync_role.sh push --git --push`; old push machines auto-downgrade to pull when their timer next sees a different global owner. Never `git push --force` from auto-sync.
