# Custom Provider Setup & Debugging

When configuring custom API providers in `custom_providers` section of `config.yaml`, authentication failures (HTTP 405, 401, 400) are common. This reference documents the debugging workflow.

## Problem: HTTP 405 "Method Not Allowed" on Valid Endpoints

**Symptom:** A provider endpoint is genuinely compatible with OpenAI API format, but curl/requests to it returns HTTP 405 (Method Not Allowed) from nginx.

**Root Cause:** Base URL path misconfiguration. The endpoint may be deployed on a subdomain or require a path prefix not mentioned in public docs.

### Debugging Process

1. **Test the base URL directly** (not the full `/chat/completions` path):
   ```bash
   curl -s https://api-provider.com/v1/chat/completions \
     -H "Authorization: Bearer YOUR_KEY" \
     -H "Content-Type: application/json" \
     -d '{"model": "gpt-4", "messages": [{"role": "user", "content": "test"}], "max_tokens": 5}'
   ```

2. **If 405, try variant base URLs:**
   - `https://provider.com/v1` (no `/api` prefix)
   - `https://provider.com/api/v1` (with `/api`)
   - `https://api.provider.com/v1` (api as subdomain)
   - `https://provider.com/api` (no version suffix)

3. **Compare against working endpoints** — use curl to test models you know work and capture the exact URL structure.

4. **Verify the provider's docs** — sometimes the "base_url" they advertise is not meant to be used directly; they may list example endpoints.

## Example: gptsapi.net

**Failed config:**
```yaml
custom_providers:
- name: Gptsapi
  base_url: https://gptsapi.net/v1
  api_key: sk-xxx
  model: gpt-5.5
```

Result: HTTP 405 for all requests to `https://gptsapi.net/v1/chat/completions`.

**Root cause:** The actual endpoint is on the `api.` subdomain, not the root domain.

**Working config:**
```yaml
custom_providers:
- name: Gptsapi-OpenAI
  base_url: https://api.gptsapi.net/v1
  api_key: sk-xxx
  model: gpt-5.5
```

Result: HTTP 200, responses arrive as expected.

## Testing Multiple Variants Programmatically

When unsure, use Python to test multiple configurations in parallel:

```python
import requests

configs = [
    {"name": "v1 direct", "url": "https://provider.com/v1/chat/completions"},
    {"name": "api prefix", "url": "https://provider.com/api/v1/chat/completions"},
    {"name": "api subdomain", "url": "https://api.provider.com/v1/chat/completions"},
]

for cfg in configs:
    try:
        resp = requests.post(
            cfg["url"],
            headers={"Authorization": f"Bearer {API_KEY}", "Content-Type": "application/json"},
            json={"model": "gpt-4", "messages": [{"role": "user", "content": "test"}], "max_tokens": 5},
            timeout=5
        )
        print(f"{cfg['name']:20} → HTTP {resp.status_code}")
    except Exception as e:
        print(f"{cfg['name']:20} → {type(e).__name__}")
```

## Custom Providers in `config.yaml`

Format:
```yaml
custom_providers:
- name: <provider-name>          # Used in webhook_subscriptions.json, etc.
  base_url: <https://...>        # Must NOT include /chat/completions or /messages
  api_key: sk-...                # API key; can also use env vars
  model: <model-name>            # Default model when no override given
```

**Important:** `base_url` should end at the version level (`/v1`, not `/v1/chat/completions`).

### Multiple Models from One Provider

You cannot configure multiple models per custom_provider entry. Workaround: create separate provider entries:

```yaml
custom_providers:
- name: Gptsapi-OpenAI
  base_url: https://api.gptsapi.net/v1
  api_key: sk-xxx
  model: gpt-5.5

- name: Gptsapi-Claude  # Different name, same base_url but different model
  base_url: https://api.gptsapi.net/v1
  api_key: sk-xxx
  model: claude-3-opus
```

Then reference by name in webhook subscriptions or model switches.

## Using Custom Providers in Webhooks

Once a custom provider is defined in `config.yaml`, reference it by name in `webhook_subscriptions.json`:

```json
{
  "my-webhook": {
    "provider": "Gptsapi-OpenAI",
    "model": "gpt-5.5",
    "prompt": "..."
  }
}
```

## Hermes Log Locations for Debugging

- **Agent logs:** `~/.hermes/logs/agent.log`
- **Error logs:** `~/.hermes/logs/errors.log`
- **Gateway logs:** `~/.hermes/logs/gateway.log`

Search for:
- `API call failed`
- Provider name
- `405`, `401`, `400` status codes
- `Could not detect context length` (indicates connectivity issue)

Example grep:
```bash
grep -i "gptsapi\|405\|auth" ~/.hermes/logs/agent.log | tail -20
```

## API Compatibility Notes

### OpenAI API Format
- Base URL format: `https://...../v1`
- Auth: `Authorization: Bearer <key>`
- Endpoint: `POST /chat/completions`
- Request body: `{"model": "...", "messages": [...], ...}`

### Anthropic/Claude API Format
- Base URL format: `https://...../v1`
- Auth: `x-api-key: <key>` + `anthropic-version: 2023-06-01`
- Endpoint: `POST /messages`
- Request body: `{"model": "...", "messages": [...], "max_tokens": ...}`

Some proxies (e.g., gptsapi.net) claim to support both formats but may only implement OpenAI-style endpoints. Test with a simple curl request to confirm before investing time in configuration.

## Common Pitfalls

1. **Including `/chat/completions` in `base_url`** — base_url should be `https://api.../v1`, not `https://api.../v1/chat/completions`. Hermes appends the endpoint path automatically.

2. **Wrong subdomain** — many providers have multiple domain variants; the main root domain may not have the API. Test `api.` subdomain first.

3. **Stale or incorrect documentation** — if the provider's public docs say `/v1` works but tests fail, assume their docs are outdated and try variant paths systematically.

4. **Model name mismatch** — even if the endpoint works, the model name you specify may not exist on that provider. Error will be `"model not found <name>"`.

5. **API key format** — verify the key hasn't been truncated or corrupted. Some keys are environment-specific; test the exact key you're using.

## When to Ask the User for New Credentials

If the user says "this API is fully compatible with OpenAI format," but:
- Testing shows HTTP 405 on all variant paths
- The subdomain structure doesn't match typical patterns
- Or the endpoint genuinely does not support the expected models

Ask for:
1. **Official API docs URL** or a direct link to their integration guide
2. **A working example curl command** (with placeholder key)
3. **The correct base_url** they recommend for integration
4. **List of available model names** (sometimes not the same as OpenAI's)

Then test those specifics before integrating into Hermes config.
