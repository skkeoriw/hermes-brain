# Webhook + API Server pattern for Git-backed llm-wiki automation

Session-derived pattern for exposing a single Hermes entrypoint that controls a remote Git-backed wiki.

## Use case

A GitHub-hosted Obsidian/markdown wiki should be maintained by Hermes using the `llm-wiki` skill. External callers need to trigger:

- `full_build`: sync repo, scan all markdown, initialize/repair schema/index/log/pages/links, commit, push.
- `incremental_build`: sync repo, process only changed markdown and affected pages, commit, push.
- `query`: sync repo, answer from the wiki, write valuable answers to `queries/`, commit, push.

## Recommended shape

Use one webhook subscription (for async trigger + Telegram/other delivery) and optionally API Server (for synchronous return):

- Webhook route: `/webhooks/wiki-ops`
- Payload fields:
  - `action`: `full_build` | `incremental_build` | `query`
  - `question`: query text for `query`
  - `save`: whether query output should be written to `queries/` (default true if user wants query capture)
  - `run_id`: caller-supplied task identifier for traceability. It is not a Hermes-generated value; use timestamped IDs such as `full-build-YYYYMMDD-HHMMSS`. Reuse it in `X-Request-ID` so the webhook `delivery_id`, gateway logs, Telegram summary, and wiki run log line up.
- Stable clone path example: `/home/<user>/wiki/<repo-name>`
- Set both env vars to the clone when Obsidian-style tooling should share the vault:
  - `WIKI_PATH=/home/<user>/wiki/<repo-name>`
  - `OBSIDIAN_VAULT_PATH=/home/<user>/wiki/<repo-name>`

## Webhook payload and trace conventions

For long-running wiki actions, include a user-chosen `run_id` in the JSON payload and also pass the same value as `X-Request-ID`:

```json
{"action":"full_build","run_id":"full-build-20260503-080000"}
```

```http
X-Request-ID: full-build-20260503-080000
```

Hermes uses `X-Request-ID` as the webhook `delivery_id`; without it, the adapter generates a millisecond timestamp. Matching `run_id` and `delivery_id` makes it much easier to correlate gateway logs, Telegram output, session JSON, git commits, and task-created run logs.

For Postman/simple callers, prefer fixed-token auth over dynamic body signatures:

```http
X-Gitlab-Token: <route-secret>
```

This uses the same route secret but does not require recalculating HMAC when the JSON body changes. Keep HMAC (`X-Hub-Signature-256`) for GitHub-style integrations or when the caller can sign the exact raw body.

A normal async webhook response looks like:

```json
{"status":"accepted","route":"wiki-ops","event":"unknown","delivery_id":"..."}
```

`event=unknown` is fine when the subscription accepts all events. Completion is visible later in gateway logs as `response ready: platform=webhook chat=webhook:<route>:<delivery_id>` and via the configured delivery target (e.g. Telegram).

## Prompt ingredients

The webhook/API prompt should explicitly require:

1. Verify clean worktree; stop on uncommitted changes unless instructed otherwise.
2. `git fetch origin <branch> && git checkout <branch> && git pull --ff-only origin <branch>` before any wiki work.
3. Create or append a per-run execution log inside the wiki, e.g. `logs/webhook-runs/{run_id}.md`; if no `run_id` was supplied, use delivery ID or UTC timestamp. Include payload, start/end times, sync commands/results, scanned file counts, key files read, files created/updated/deleted, `git status`, commit hash, push result, and errors.
4. Use llm-wiki orientation: read `SCHEMA.md`, `index.md`, and recent `log.md`; initialize them if missing.
5. Branch by payload action:
   - full build = all markdown / graph repair.
   - incremental build = changed markdown and affected pages.
   - query = answer from wiki; write `queries/` when configured.
6. Update `index.md` and `log.md` for any durable wiki changes.
7. Commit only if `git status` shows changes.
8. Push only to the user-approved branch (direct `main` only if explicitly requested).
9. Final report includes action, sync status, files changed, commit hash, push result, answer/summary, errors, and the run-log path.

## Webhook vs API Server

Webhook subscriptions are asynchronous triggers. The HTTP caller typically receives only an accepted/ok response; final output is delivered through `--deliver` (e.g. Telegram) or logs. A successful response such as `{"status":"accepted","route":"wiki-ops","event":"unknown","delivery_id":"..."}` means the request was accepted and queued/running; it does not mean the agent finished. `event: "unknown"` is normal for generic JSON calls unless an event header such as `X-GitHub-Event` is supplied; it still runs when the route's event filter is empty/all.

API Server is the synchronous interface. Use OpenAI-compatible `/v1/chat/completions` when the caller must receive the final Hermes answer in the HTTP response.

It is valid to enable both:

- webhook for external automation and Telegram delivery;
- API Server for programmatic calls that need a returned answer.

## API Server session continuity

For synchronous automation that should preserve conversation context across calls, prefer explicit session continuity instead of relying on default fingerprinting:

- `/v1/chat/completions` supports `X-Hermes-Session-Id: <stable-id>`.
  - Requires `API_SERVER_KEY` to be configured and the request to authenticate with `Authorization: Bearer <key>`.
  - When present, Hermes loads history for that session from `state.db` instead of trusting the request body history.
  - Good IDs are business-scoped, e.g. `wiki-query-main`, `wiki-build-main`, `wiki-user-<id>`, or `wiki-project-<repo>`.
  - Avoid a single global session for unrelated operations; compression will eventually summarize old context, but mixed build/query/admin history can pollute decisions.
- If no explicit header is provided, `/v1/chat/completions` derives a stable `api-<hash>` session from the system prompt and first user message. This works for OpenAI-compatible frontends that resend full history, but is less predictable for backend workflows.
- `/v1/responses` is stateful via `previous_response_id`; it also supports `conversation: <name>` as a server-side alias for the latest response in that named conversation.

Long-running reused sessions participate in Hermes' normal context compression. Check `compression.enabled`, `threshold`, `target_ratio`, and `protect_last_n` in `config.yaml` when explaining behavior. Compression preserves recent messages and summaries of older context; it is not a perfect permanent memory store.

## Hermes configuration gotchas

- Enabling `.env` keys may not be enough for CLI `hermes webhook list/subscribe` if the loaded config lacks platform entries. Also ensure `config.yaml` has `platforms.webhook.enabled: true` and, for API Server, `platforms.api_server.enabled: true` plus platform toolsets (`hermes-webhook`, `hermes-api-server`) where needed.
- Restart the gateway after enabling webhook/API Server; otherwise ports such as 8644/8642 will not listen.
- If tool approval blocks `hermes gateway restart`, tell the user to run it manually rather than retrying.
- Verify webhook health with `curl http://localhost:<port>/health`; expected body includes `{"status":"ok","platform":"webhook"}`.
- Verify request handling with `grep -i "<delivery_id>\|wiki-ops\|webhook" ~/.hermes/logs/gateway.log | tail -120`; look for POST, inbound message, response ready, API call count, and delivery lines.
- For manual/Postman webhook calls, prefer fixed-token auth: pass `X-Gitlab-Token: <subscription secret>` instead of `X-Hub-Signature-256`, unless the caller already knows how to compute HMAC over the exact raw body.
- Direct push to GitHub requires server-side Git auth; `gh` may not be installed, so validate `git push` credentials separately.
